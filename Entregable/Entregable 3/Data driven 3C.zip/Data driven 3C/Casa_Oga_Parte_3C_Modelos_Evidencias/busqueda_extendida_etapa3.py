#!/usr/bin/env python3
"""Additional tree models using same dataset/split; label uses only prior periods, test untouched."""
import os,json,time
os.environ['OMP_NUM_THREADS']='3';os.environ['OPENBLAS_NUM_THREADS']='3';os.environ['MKL_NUM_THREADS']='3'
from pathlib import Path
import numpy as np,pandas as pd
from lightgbm import LGBMClassifier,LGBMRanker
from catboost import CatBoostClassifier
from sklearn.ensemble import ExtraTreesClassifier,RandomForestClassifier,HistGradientBoostingClassifier
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import roc_auc_score,average_precision_score
DATA=Path('/mnt/data/casa_oga_work/Gerocasla Casa-Oga-Data-driven main/Entregable 3/Casa_Oga_Modelos_Reproducibles (3)/dataset_entrenamiento_v3.csv')
OUT=Path('/mnt/data/casa_oga_work')
df=pd.read_csv(DATA)
df=df[df.split.isin(['train','validacion'])].reset_index(drop=True)
features=[c for c in df.columns if c not in {'fecha_mes','id_tienda','id_producto','costo_imputado','target_cob12_t3','split'}]
extra=['id_tienda','id_producto'];features_plus=features+extra
cat=['categoria','subcategoria','region','formato','proveedor'];catplus=cat+extra
num=[c for c in features if c not in cat]
for c in num:df[c]=df[c].replace([np.inf,-np.inf],[1e3,-1e3])
T=df['target_cob12_t3'].astype(np.int8).values
ms=df['fecha_mes'].values
inner_train=(df.split=='train')&(df.fecha_mes<='2024-03-01'); inner_val=(df.split=='train')&(df.fecha_mes>='2024-07-01')
train=df.split=='train';val=df.split=='validacion'
X=df[features_plus].copy();Xcat=X.copy(); Xlgb=X.copy()
for c in catplus:
 Xcat[c]=Xcat[c].fillna('Desconocido').astype(str)
 Xlgb[c]=Xlgb[c].fillna('Desconocido').astype('category')
for c in num:Xcat[c]=Xcat[c].fillna(Xcat.loc[inner_train,c].median())
Xenc=X.copy()
Xenc[catplus]=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1).fit_transform(Xenc[catplus].fillna('Desconocido'))
for c in num:Xenc[c]=Xenc[c].fillna(Xenc.loc[inner_train,c].median())
Xenc=Xenc.astype('float32')

def metr(p,mask,ks=(600,420,100,200,800)):
 dd=pd.DataFrame({'mes':ms[mask],'y':T[mask],'score':p})
 dd=dd.sort_values(['mes','score'],ascending=[True,False],kind='mergesort');dd['rnk']=dd.groupby('mes',sort=False).cumcount()+1
 positives=int(dd['y'].sum());a={'auc':float(roc_auc_score(dd['y'],dd['score'])),'pr_auc':float(average_precision_score(dd['y'],dd['score'])),'positives':positives}
 for k in ks:
  idx=dd['rnk']<=k; n=int(idx.sum());tp=int(dd.loc[idx,'y'].sum());re=tp/positives;pr=tp/n
  a[f'k{k}']={'tp':tp,'fp':n-tp,'fn':positives-tp,'recall':re,'precision':pr,'f1':2*pr*re/(pr+re)}
 return a

def model_run(fam,params,tmask,vmask,include_ids=False):
 cl=catplus if include_ids else cat
 f=features_plus if include_ids else features
 if fam=='CatBoost':
  m=CatBoostClassifier(loss_function='Logloss',verbose=False,random_seed=0,thread_count=3,allow_writing_files=False,**params)
  m.fit(Xcat.loc[tmask,f],T[tmask],cat_features=cl)
  pred=m.predict_proba(Xcat.loc[vmask,f])[:,1]
 elif fam=='LightGBM':
  m=LGBMClassifier(objective='binary',random_state=0,n_jobs=3,verbosity=-1,**params)
  m.fit(Xlgb.loc[tmask,f],T[tmask])
  pred=m.predict_proba(Xlgb.loc[vmask,f])[:,1]
 elif fam=='LightGBMRanker':
  m=LGBMRanker(objective='lambdarank',label_gain=[0,1],random_state=0,n_jobs=3,verbosity=-1,**params)
  tx=Xlgb.loc[tmask,f]; vx=Xlgb.loc[vmask,f]
  trsort=np.argsort(ms[tmask],kind='mergesort'); rowcounts=pd.Series(ms[tmask][trsort]).value_counts(sort=False).sort_index().to_numpy()
  m.fit(tx.iloc[trsort],T[tmask][trsort],group=rowcounts)
  pred=m.predict(vx)
 elif fam=='ExtraTrees':
  m=ExtraTreesClassifier(n_jobs=3,random_state=0,class_weight='balanced_subsample',**params)
  m.fit(Xenc.loc[tmask,f],T[tmask]);pred=m.predict_proba(Xenc.loc[vmask,f])[:,1]
 return pred,m

configs=[]
def add(fam,name,ids=False,**params):configs.append({'fam':fam,'name':name,'ids':ids,'params':params})
for name,depth,leaf,trees,l2,ids in [('cat_base_5',5,.045,550,5,False),('cat_base_7',7,.04,650,8,False),('cat_sku_5',5,.045,650,5,True),('cat_sku_7',7,.035,700,8,True),('cat_sku_4',4,.07,500,5,True)]:
 add('CatBoost',name,ids,depth=depth,learning_rate=leaf,iterations=trees,l2_leaf_reg=l2,auto_class_weights='Balanced')
for name,leaves,lr,trees,minleaf,ids in [('lgb_sku_1',31,.04,550,50,True),('lgb_sku_2',15,.045,750,80,True),('lgb_sku_3',63,.025,750,100,True)]:
 add('LightGBM',name,ids,n_estimators=trees,learning_rate=lr,num_leaves=leaves,min_child_samples=minleaf,colsample_bytree=.85,reg_lambda=4,reg_alpha=.5,cat_smooth=20,class_weight='balanced')
for name,leaves,lr,trees,trunc in [('rank_1',31,.05,300,100),('rank_2',15,.04,450,250)]:
 add('LightGBMRanker',name,False,n_estimators=trees,learning_rate=lr,num_leaves=leaves,min_child_samples=60,lambdarank_truncation_level=trunc,reg_lambda=3,colsample_bytree=.85)
add('ExtraTrees','extra_sku_1',True,n_estimators=300,min_samples_leaf=12,max_features=.8)
configs=[c for c in configs if c["name"] in ["cat_sku_5","cat_sku_4","lgb_sku_1","lgb_sku_2","rank_1","rank_2"]]
innerres=[];valres=[];fails=[]
for i,c in enumerate(configs):
 start=time.time()
 try:
  p,_=model_run(c['fam'],c['params'],inner_train,inner_val,c['ids']);mt=metr(p,inner_val)
  innerres.append({**c,'inner':mt,'seconds':round(time.time()-start,1)})
  print('INNER',i+1,len(configs),c['name'],'tp600',mt['k600']['tp'],'recall',round(mt['k600']['recall'],5),'t',round(time.time()-start,1),flush=True)
 except Exception as e:print('FAILED',c['name'],str(e)[:600],flush=True);fails.append({**c,'error':str(e)})
 (OUT/'arboreos_ext_progreso.json').write_text(json.dumps({'inner':innerres,'fails':fails},ensure_ascii=False,indent=2))

families=sorted({c['fam'] for c in innerres});chosen=[]
for family in families:
 a=sorted([x for x in innerres if x['fam']==family],key=lambda t:(t['inner']['k600']['tp'],t['inner']['auc']),reverse=True)
 chosen+=a[:2] if family=='CatBoost' else a[:2]
print('SELECTED',[c['name'] for c in chosen],flush=True)
for i,c in enumerate(chosen):
 start=time.time()
 try:
  p,m=model_run(c['fam'],c['params'],train,val,c['ids']);mt=metr(p,val)
  valres.append({**c,'val':mt,'seconds_full':round(time.time()-start,1)})
  np.save(OUT/f'pred_{c["name"]}.npy',p)
  print('VALIDACION',i+1,len(chosen),c['name'],'tp600',mt['k600']['tp'],'recall',round(mt['k600']['recall'],5),'t',round(time.time()-start,1),flush=True)
 except Exception as e:print('FAILED VAL',c['name'],str(e)[:600],flush=True);fails.append({**c,'error':str(e)})
 (OUT/'arboreos_ext_progreso.json').write_text(json.dumps({'inner':innerres,'validacion':valres,'fails':fails},ensure_ascii=False,indent=2))
(OUT/'arboreos_ext_resultados.json').write_text(json.dumps({'inner':innerres,'validacion':valres,'fails':fails},ensure_ascii=False,indent=2))

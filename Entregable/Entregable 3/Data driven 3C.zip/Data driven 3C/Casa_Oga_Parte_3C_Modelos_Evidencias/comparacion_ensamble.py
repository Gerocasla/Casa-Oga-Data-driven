import json,numpy as np,pandas as pd
from pathlib import Path
script=Path('/mnt/data/casa_oga_work/busqueda_arboles_etapa3.py').read_text().split('configs=[]')[0];N={};exec(script,N)
out=Path('/mnt/data/casa_oga_work');data=json.load(open(out/'modelos_arboreos_primera_fase.json'))
need=['original','extra_2','lgb_6','xgb_4']
configs={x['name']:x for x in data['inner']}
pinner={}
for name in need:
 c=configs[name];p,_=N['fit_predict'](c['family'],c['params'],N['train0'],N['inner']);pinner[name]=p
 print('inner',name,N['performance'](p,N['inner'])['k600']['tp'],flush=True)
mask=N['inner'];groups=pd.Series(N['months'][mask])
def pct(scores,period):return pd.Series(scores).groupby(pd.Series(N['months'][period])).rank(method='average',pct=True).to_numpy()
def ensemble(mask,predset,names):return N['performance'](np.mean([pct(predset[k],mask) for k in names],axis=0),mask)
combos=[['original','extra_2'],['original','lgb_6'],['original','xgb_4'],['original','extra_2','lgb_6'],['original','extra_2','xgb_4'],['original','lgb_6','xgb_4']]
res=[]
for names in combos:
 mi=ensemble(mask,pinner,names)
 print('ensemble inner',names,mi['k600']['tp'],round(mi['k600']['recall'],4),flush=True)
 pv={k:np.load(out/f'pred_{k}.npy') for k in names};ev=ensemble(N['valid'],pv,names)
 print('ensemble valid',names,ev['k600']['tp'],round(ev['k600']['recall'],4),flush=True)
 res.append({'models':names,'inner':mi,'validacion':ev})
(out/'ensambles_resultados.json').write_text(json.dumps(res,indent=2))

# Casa Óga · Entregable 3C — búsqueda de modelos arbóreos

## Fuente exacta

El CSV de trabajo es **`dataset_entrenamiento_v3.csv`**, copiado sin modificar desde
`Gerocasla Casa-Oga-Data-driven main/Entregable 3/Casa_Oga_Modelos_Reproducibles (3)/dataset_entrenamiento_v3.csv`.

Se comprobó que contiene **201.306 registros y 66 columnas**: `train` 98.649, `validacion` 38.362, `embargo` 36.225 y `test` 28.070. Se usa el objetivo original `target_cob12_t3`. El algoritmo trabaja exclusivamente con `train` y `validacion`. Los otros splits no se emplearon en los ajustes ni se utilizaron para elegir la arquitectura.

## Diseño experimental

- Selección preliminar de parámetros: entrenamiento hasta marzo de 2024, embargo abril-junio de 2024 y evaluación interna julio-diciembre de 2024.
- Evaluación externa para selección del candidato: entrenamiento completo hasta diciembre de 2024 y validación abril-septiembre de 2025.
- **Métrica principal**: Recall@600, con **600 alertas por mes** y seis meses de validación. Se mantienen idénticos período, etiquetas y número de alertas para la comparación.
- Familias de árboles exploradas: HistGradientBoosting, ExtraTrees, RandomForest, XGBoost, LightGBM, CatBoost y LightGBMRanker. Se probaron diferentes hiperparámetros y combinaciones de modelos. Algunas ejecuciones exploratorias que fallaron se identifican en los JSON y no fueron computadas como pruebas válidas.
- Modelo seleccionado: **promedio simple de percentiles de ranking, dentro de cada mes**, de HistGradientBoosting, ExtraTrees y LightGBM. Ese promedio no representa una probabilidad calibrada.

## Comparación principal — validación abril–septiembre 2025

| Métrica | Modelo original 3A/3B | Ensamble 3C | Cambio |
| --- | ---: | ---: | ---: |
| Verdaderos positivos | 585 | 606 | +21 |
| Falsos positivos | 3.015 | 2.994 | −21 |
| Recall@600 | 68,50% | 70,96% | +2,46 puntos |
| Precisión@600 | 16,25% | 16,83% | +0,58 puntos |
| F1@600 | 26,27% | 27,21% | +0,94 puntos |

El modelo nuevo mejora el conteo de verdaderos positivos en los seis meses. La ventaja observada corresponde únicamente a esta validación y **no prueba que el aumento se mantenga en el test 2026**. Hay señales de sobreajuste: recall@600 de entrenamiento 99,72% en el ensamble, frente al 93,59% del modelo original; la brecha entrenamiento-validación aumenta.

## Reproducción

Instalar versiones compatibles de `python`, `pandas`, `numpy`, `scikit-learn`, `lightgbm`, `joblib` y `matplotlib` (las versiones exactas del entorno se encuentran en los resultados del proyecto y los scripts). Desde la carpeta que contiene el CSV:

```bash
python modelo_ensamble_final.py
```

El script produce `ensamble_etapa3_resultados.json`, `ensamble_2025_predicciones_validacion.csv`, `ensamble_importancia_variables.png` y `ensamble_modelos_arboles.joblib`.

El archivo `modelos_arboreos_resultados.json` registra resultados de la primera comparación, `arboreos_ext_resultados.json` las pruebas adicionales por SKU y ranking, y `ensambles_resultados.json` la selección temporal de combinaciones.

## Lectura económica

Se preservó la referencia económica de **ROI optimista +27,1% a tres años** del Entregable 3B. El nuevo ensamble detecta 158 casos más que la regla de cobertura (606−448), frente a 137 del original; esto incrementa los aciertos adicionales contra la regla un **15,3%**. Si exclusivamente la porción del beneficio optimista atribuible a esos aciertos escala en igual proporción y no aumentan los costos, el **ROI estimado a tres años pasaría condicionalmente a +37,9%**. Es una sensibilidad, no un resultado observado; tampoco satisface el recupero máximo de 12 meses.

## Archivos

- `Casa_Oga_Entregable_3_Parte_C_Modelos_Arboles.docx`: informe completo corregido.
- `dataset_entrenamiento_v3.csv`: copia exacta del dataset de proyecto.
- `modelo_ensamble_final.py`: script independiente que vuelve a entrenar los tres estimadores seleccionados.
- `busqueda_arboles_etapa3.py` y `busqueda_extendida_etapa3.py`: exploración de familias e hiperparámetros.
- `ensamble_etapa3_resultados.json`: métricas finales, segmentación, umbrales y ejemplo real.
- `ensamble_2025_predicciones_validacion.csv`: observaciones, scores de componentes, rank ensemble y alertas del período de validación.
- `ensamble_importancia_variables.png`: importancia por ganancia del componente LightGBM (no efecto causal ni importancia global del ensamble completo).
- `ensamble_modelos_arboles.joblib`: los tres modelos ya entrenados y el preprocesamiento.

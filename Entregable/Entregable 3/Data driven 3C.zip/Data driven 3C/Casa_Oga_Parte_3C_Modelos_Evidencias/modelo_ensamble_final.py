#!/usr/bin/env python3
"""CASA OGA | Etapa 3 | Ensamble de árboles.
Fuente ÚNICA: dataset_entrenamiento_v3.csv del Entregable 3.
ÚNICOS splits utilizados: train, validacion. No test ni embargo como datos de entrenamiento/evaluación.
Predicción Top-600 POR MES y agregación de percentiles de ranking (no son probabilidades calibradas).
"""
import os, json, time
os.environ.setdefault('OMP_NUM_THREADS','4');os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier,ExtraTreesClassifier
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import roc_auc_score,average_precision_score
from lightgbm import LGBMClassifier
import joblib

DATA=Path(__file__).parent/'dataset_entrenamiento_v3.csv'
OUT=Path(__file__).parent
assert DATA.is_file(),f'Falta CSV original: {DATA}'
all_meta=pd.read_csv(DATA,usecols=['split'])
assert len(all_meta)==201306
used=pd.read_csv(DATA)
assert 'test' in used.split.unique()
used=used.loc[used.split.isin(['train','validacion'])].copy().reset_index(drop=True)
train=used.split=='train';val=used.split=='validacion'
Y=used.target_cob12_t3.astype(int).to_numpy()
feature_cols=[c for c in used.columns if c not in {'fecha_mes','id_tienda','id_producto','costo_imputado','target_cob12_t3','split'}]
cat=[c for c in feature_cols if used[c].dtype==object]
num=[c for c in feature_cols if c not in cat]
for col in num:used[col]=used[col].replace([np.inf,-np.inf],[1000.,-1000.])
X=used[feature_cols].copy()
X_cat=X.copy()
for c in cat:
 levels=sorted(X_cat.loc[train,c].dropna().unique())
 X_cat[c]=pd.Categorical(X_cat[c],categories=levels)
X_enc=X.copy()
enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1,encoded_missing_value=-2)
# Fit encoding on training only; every non-null category in the 2025 validation is present in training.
enc.fit(X.loc[train,cat].fillna('Desconocido'))
X_enc[cat]=enc.transform(X[cat].fillna('Desconocido'))
# La configuración ExtraTrees se seleccionó con medianas calculadas exclusivamente
# sobre subentrenamiento temporal <= marzo 2024: conservar esa transformación en el modelo final.
mask_previo=(used.split=='train')&(used.fecha_mes<='2024-03-01')
med=X.loc[mask_previo,num].median()
for c in num:X_enc[c]=X_enc[c].fillna(med[c]).astype('float32')
X_enc=X_enc.astype('float32')

models={
 'HistGradientBoosting':HistGradientBoostingClassifier(max_iter=300,learning_rate=.05,class_weight='balanced',categorical_features='from_dtype',random_state=0),
 'ExtraTrees':ExtraTreesClassifier(n_estimators=350,min_samples_leaf=15,max_features=.8,n_jobs=4,random_state=0,class_weight='balanced_subsample'),
 'LightGBM':LGBMClassifier(objective='binary',class_weight='balanced',random_state=0,n_jobs=4,verbosity=-1,n_estimators=700,learning_rate=.025,num_leaves=45,min_child_samples=40,subsample=.8,subsample_freq=1,colsample_bytree=.8,reg_lambda=4,reg_alpha=.5,max_bin=255),
}
probs={}
for name,model in models.items():
 st=time.time(); xx=X_enc if name=='ExtraTrees' else X_cat
 model.fit(xx.loc[train],Y[train]);probs[name]=model.predict_proba(xx.loc[val])[:,1]
 print('Entrenado',name,round(time.time()-st,1),'segundos',flush=True)

d=used.loc[val,['fecha_mes','id_tienda','id_producto','categoria','region','stock_disponible','cobertura','u6_suma','meses_sin_venta','target_cob12_t3']].reset_index(drop=True)
for name,p in probs.items():d['pred_'+name]=p;d['pct_'+name]=pd.Series(p).groupby(d.fecha_mes).rank(method='average',pct=True)
d['score_ensamble']=d[[f'pct_{k}' for k in models]].mean(axis=1)
# deterministic stable monthly sorted selection
def select_k(score,k):
 tmp=d[['fecha_mes']].copy();tmp['score']=score
 selected=tmp.sort_values(['fecha_mes','score'],ascending=[True,False],kind='mergesort').groupby('fecha_mes',sort=False).head(k).index
 return d.index.isin(selected)
y=d.target_cob12_t3.values.astype(int)
def evaluate(sel):
 n=int(sel.sum());tp=int(y[sel].sum()); pos=int(y.sum()); pr=tp/n if n else 0;re=tp/pos
 return {'alertas':n,'vp':tp,'fp':n-tp,'fn':pos-tp,'vn':len(y)-pos-(n-tp),'precision':pr,'recall':re,'f1':2*pr*re/(pr+re) if pr+re else 0,'valor_neto_6m_usd':round(tp*10.04-(n-tp)*2.2,2)}
results={
 'fuente':str(DATA),
 'sha256':__import__('hashlib').sha256(DATA.read_bytes()).hexdigest(),
 'filas_fuente':201306,'train':int(train.sum()),'validacion':int(val.sum()),'target_positivos':int(y.sum()),
 'politica_temporal':'solo train (hasta dic-2024) -> validacion (abr-sep 2025); embargo y test excluidos',
 'modelos':{},'ensamble':{},'comparacion_mensual':[],
 'umbral':'score_ensamble = promedio de percentiles mensuales de 3 rankings; NO probabilidad calibrada'
}
for name in models:
 sc=d['pred_'+name].values;metrics=evaluate(select_k(sc,600));metrics['auc']=float(roc_auc_score(y,sc));metrics['pr_auc']=float(average_precision_score(y,sc))
 results['modelos'][name]=metrics
for k in [100,200,420,600,800]:results['ensamble'][f'top_{k}']=evaluate(select_k(d['score_ensamble'].values,k))
for t in [.85,.88,.90,.92,.94,.95,.97]:results['ensamble'][f'percentil_{t}']=evaluate(d['score_ensamble'].values>=t)
selected=select_k(d['score_ensamble'].values,600); selected_orig=select_k(d['pred_HistGradientBoosting'].values,600)
d['alerta_ensamble']=selected.astype(int);d['alerta_original']=selected_orig.astype(int)
for month,g in d.groupby('fecha_mes'):
 results['comparacion_mensual'].append({'mes':month,'positivos':int(g.target_cob12_t3.sum()),'original_vp':int((g.alerta_original*g.target_cob12_t3).sum()),'ensamble_vp':int((g.alerta_ensamble*g.target_cob12_t3).sum())})
results['auc_ensamble_rank']=float(roc_auc_score(y,d['score_ensamble']))
results['pr_auc_ensamble_rank']=float(average_precision_score(y,d['score_ensamble']))
segments={}
for group in ['categoria','region']:
 rows=[]
 for key,g in d.groupby(group):
  p=int(g.target_cob12_t3.sum());tp=int((g.target_cob12_t3*g.alerta_ensamble).sum());n=int(g.alerta_ensamble.sum());
  rows.append({'segmento':str(key),'registros':len(g),'positivos':p,'alertas':n,'vp':tp,'recall':tp/p if p else None,'precision':tp/n if n else None})
 segments[group]=sorted(rows,key=lambda z:z['recall'] if z['recall'] is not None else 0)
results['segmentos']=segments
comparison={'original':results['modelos']['HistGradientBoosting'],'ensamble':results['ensamble']['top_600']}
results['casos_recuperados_nuevos']=int((selected&~selected_orig&(y==1)).sum())
results['casos_perdidos_originales']=int((~selected&selected_orig&(y==1)).sum())
results['cambio_marginal_net_6m_usd']=round(results['ensamble']['top_600']['valor_neto_6m_usd']-results['modelos']['HistGradientBoosting']['valor_neto_6m_usd'],2)
# feature importance of tree-component: LightGBM gain (not direct coefficient or influence of full ensemble)
lgb_gain=models['LightGBM'].booster_.feature_importance(importance_type='gain')
lgb_importance=sorted([{'variable':f,'gain_pct':float(100*g/lgb_gain.sum())} for f,g in zip(feature_cols,lgb_gain)],key=lambda r:r['gain_pct'],reverse=True)
results['lightgbm_importancia_gain']=lgb_importance
# Example true positive among early score rows, with highest coverage and low sales if available.
tp_rows=d[(d.alerta_ensamble==1)&(d.target_cob12_t3==1)]
ex=tp_rows.sort_values(['score_ensamble','cobertura'],ascending=[False,False]).iloc[0]
results['ejemplo_real_validacion']={k:(str(ex[k]) if k in ['fecha_mes','id_tienda','id_producto','categoria','region'] else float(ex[k])) for k in ['fecha_mes','id_tienda','id_producto','categoria','region','stock_disponible','cobertura','u6_suma','meses_sin_venta','score_ensamble','target_cob12_t3']}
OUT.joinpath('ensamble_etapa3_resultados.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
d.to_csv(OUT/'ensamble_2025_predicciones_validacion.csv',index=False)
joblib.dump({'modelos':models,'encoder':enc,'medianas':med,'features':feature_cols,'categoricas':cat},OUT/'ensamble_modelos_arboles.joblib',compress=3)
# chart for evidence
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(9.2,4.9));imp=lgb_importance[:12][::-1]
ax.barh([e['variable'] for e in imp],[e['gain_pct'] for e in imp]);ax.set_xlabel('Porcentaje del gain total (LightGBM)');ax.set_title('Importancia de variables del componente LightGBM');ax.text(0,-2.2,'Importancia relativa del componente; no es efecto causal ni importancia del ensamble completo.',fontsize=8)
fig.tight_layout();fig.savefig(OUT/'ensamble_importancia_variables.png',dpi=160,bbox_inches='tight');plt.close(fig)
print(json.dumps(comparison,ensure_ascii=False,indent=2),flush=True)
print('FINAL',OUT/'ensamble_etapa3_resultados.json',flush=True)

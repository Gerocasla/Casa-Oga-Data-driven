#!/usr/bin/env python3
"""Reproducción Etapa 3: selección temporal interna + validación 2025 (sin test ni embargo).
Dataset requerido: Entregable 3/Casa_Oga_Modelos_Reproducibles (3)/dataset_entrenamiento_v3.csv
"""
import os, json, time, warnings, sys
os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['MKL_NUM_THREADS']='4'
from pathlib import Path
from collections import defaultdict
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score
from sklearn.ensemble import HistGradientBoostingClassifier, ExtraTreesClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OrdinalEncoder
from lightgbm import LGBMClassifier, log_evaluation
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
DATA=Path('/mnt/data/casa_oga_work/Gerocasla Casa-Oga-Data-driven main/Entregable 3/Casa_Oga_Modelos_Reproducibles (3)/dataset_entrenamiento_v3.csv')
OUT=Path('/mnt/data/casa_oga_work')
df=pd.read_csv(DATA)
assert len(df)==201306
assert set(df['split'])=={'train','validacion','embargo','test'}
use=df['split'].isin(['train','validacion']);df=df[use].reset_index(drop=True)
target='target_cob12_t3'
exclude={'fecha_mes','id_tienda','id_producto','costo_imputado',target,'split'}
features=[x for x in df.columns if x not in exclude]
cat=[c for c in features if df[c].dtype=='object'];num=[c for c in features if c not in cat]
for col in num:df[col]=df[col].replace([np.inf,-np.inf],[1e3,-1e3])
train0=(df.split=='train')&(df.fecha_mes<='2024-03-01')
inner=(df.split=='train')&(df.fecha_mes>='2024-07-01')
train=(df.split=='train')
valid=(df.split=='validacion')
print('dataset',DATA.name,'shape',df.shape,'features',len(features),'cat',cat,flush=True)
print('periods',{'inner_train':(int(train0.sum()),int(df.loc[train0,target].sum())),'inner_val':(int(inner.sum()),int(df.loc[inner,target].sum())),'full_train':(int(train.sum()),int(df.loc[train,target].sum())),'official_val':(int(valid.sum()),int(df.loc[valid,target].sum()))},flush=True)
# leave native category cols for lightgbm and hist; ordinal for sklearn and xgb; raw cat strings for catboost.
X=df[features].copy()
X_cat=X.copy()
for c in cat:
 X_cat[c]=X_cat[c].fillna('Desconocido').astype('category')
X_lgb=X_cat
X_hgb=X_cat
X_cboost=X.copy()
for c in cat:X_cboost[c]=X_cboost[c].fillna('Desconocido').astype(str)
for c in num:X_cboost[c]=X_cboost[c].fillna(X_cboost.loc[train0,c].median())
X_encoded=X.copy()
enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1,encoded_missing_value=-2)
X_encoded[cat]=enc.fit_transform(X_encoded.loc[:,cat].fillna('Desconocido'))
for c in num:X_encoded[c]=X_encoded[c].fillna(X_encoded.loc[train0,c].median()).astype('float32')
X_encoded=X_encoded.astype('float32')
X_xgb=X_encoded
Y=df[target].astype(np.int8).to_numpy()
months=df['fecha_mes'].to_numpy()

def performance(scores, subset, ks=(100,200,420,600,800)):
 pos=int(Y[subset].sum()); m=pd.DataFrame({'mes':months[subset], 'y':Y[subset], 'p':scores})
 m=m.sort_values(['mes','p'],ascending=[True,False],kind='mergesort')
 m['rank']=m.groupby('mes',sort=False).cumcount()+1
 result={'auc':float(roc_auc_score(m['y'],m['p'])),'pr_auc':float(average_precision_score(m['y'],m['p'])),'positives':pos,'months':int(m.mes.nunique())}
 for k in ks:
  alerts=m['rank']<=k;tp=int(m.loc[alerts,'y'].sum()); n=int(alerts.sum()); pr=tp/n if n else 0;re=tp/pos if pos else 0
  result[f'k{k}']={'tp':tp,'fp':n-tp,'fn':pos-tp,'alerts':n,'recall':re,'precision':pr,'f1':2*pr*re/(pr+re) if pr+re else 0}
 return result

def fit_predict(family,params,tmask,vmask):
 if family=='HistGradientBoosting':
  model=HistGradientBoostingClassifier(random_state=0, class_weight='balanced', categorical_features='from_dtype',**params)
  xf=X_hgb
 elif family=='LightGBM':
  model=LGBMClassifier(objective='binary',class_weight='balanced',random_state=0,n_jobs=4,verbosity=-1,**params)
  xf=X_lgb
 elif family=='XGBoost':
  model=XGBClassifier(objective='binary:logistic',eval_metric='aucpr',tree_method='hist',random_state=0,n_jobs=4,**params)
  xf=X_xgb
 elif family=='CatBoost':
  model=CatBoostClassifier(loss_function='Logloss',verbose=False,thread_count=4,random_seed=0,auto_class_weights='Balanced',allow_writing_files=False,**params)
  xf=X_cboost
 elif family=='ExtraTrees':
  model=ExtraTreesClassifier(n_jobs=4,random_state=0,class_weight='balanced_subsample',**params)
  xf=X_encoded
 elif family=='RandomForest':
  model=RandomForestClassifier(n_jobs=4,random_state=0,class_weight='balanced_subsample',**params)
  xf=X_encoded
 if family=='CatBoost':
  model.fit(xf.loc[tmask],Y[tmask],cat_features=cat)
 else:
  model.fit(xf.loc[tmask],Y[tmask])
 return model.predict_proba(xf.loc[vmask])[:,1],model

configs=[]
def add(fam,name,**kw):configs.append({'family':fam,'name':name,'params':kw})
add('HistGradientBoosting','original',max_iter=300,learning_rate=.05,max_leaf_nodes=31,min_samples_leaf=20,l2_regularization=0)
add('HistGradientBoosting','hist_deep',max_iter=450,learning_rate=.035,max_leaf_nodes=63,min_samples_leaf=30,l2_regularization=3)
add('HistGradientBoosting','hist_shallow',max_iter=500,learning_rate=.04,max_leaf_nodes=15,min_samples_leaf=30,l2_regularization=1)
add('HistGradientBoosting','hist_narrow',max_iter=700,learning_rate=.03,max_leaf_nodes=10,min_samples_leaf=60,l2_regularization=3)
for n,leaves,lr,trees,minleaf,frac in [('lgb_1',31,.04,500,60,.8),('lgb_2',15,.035,750,60,.9),('lgb_3',63,.035,550,90,.85),('lgb_4',31,.025,900,100,.9),('lgb_5',15,.07,450,40,.75),('lgb_6',45,.025,700,40,.8)]:
 add('LightGBM',n,n_estimators=trees,learning_rate=lr,num_leaves=leaves,max_depth=-1,min_child_samples=minleaf,subsample=.8,subsample_freq=1,colsample_bytree=frac,reg_lambda=4,reg_alpha=0.5,max_bin=255)
for n,d,lr,trees,child,sub in [('xgb_1',4,.05,500,5,.85),('xgb_2',6,.035,650,10,.8),('xgb_3',3,.04,750,6,.9),('xgb_4',5,.025,850,15,.9)]:
 add('XGBoost',n,n_estimators=trees,max_depth=d,learning_rate=lr,min_child_weight=child,subsample=sub,colsample_bytree=.9,reg_lambda=6,reg_alpha=.25)
for n,d,lr,trees,l2 in [('cat_1',5,.055,550,5),('cat_2',7,.035,650,8),('cat_3',4,.045,750,4),('cat_4',6,.025,900,9)]:
 add('CatBoost',n,iterations=trees,depth=d,learning_rate=lr,l2_leaf_reg=l2)
for n,leaf,nest,feat in [('extra_1',6,220,.9),('extra_2',15,350,.8)]:add('ExtraTrees',n,n_estimators=nest,min_samples_leaf=leaf,max_features=feat,max_depth=None)
add('RandomForest','rf_1',n_estimators=250,min_samples_leaf=8,max_features=.8,max_depth=22)

inner_scores=[];fail=[]
for i,c in enumerate(configs):
 st=time.time()
 try:
  p,_=fit_predict(c['family'],c['params'],train0,inner)
  metr=performance(p,inner)
  row={**c,'inner':metr,'seconds':round(time.time()-st,1)}
  inner_scores.append(row)
  print('INNER',f'{i+1}/{len(configs)}',c['family'],c['name'],'r600',round(metr['k600']['recall'],5),'tp',metr['k600']['tp'],'auc',round(metr['auc'],5),'seconds',row['seconds'],flush=True)
 except Exception as exc:
  fail.append({'config':c,'error':str(exc)})
  print('FAILED',c['name'],repr(exc),flush=True)
 (OUT/'modelos_arboreos_progreso.json').write_text(json.dumps({'inner':inner_scores,'failed':fail},indent=2,ensure_ascii=False))

# Train up to two inner winners per distinct family for final validation 2025 + original
selected=[]
for family in sorted(set(x['family'] for x in inner_scores)):
 choices=sorted((x for x in inner_scores if x['family']==family),key=lambda x:(x['inner']['k600']['recall'],x['inner']['auc']),reverse=True)
 selected.extend(choices[:2] if family in ['LightGBM','XGBoost','CatBoost'] else choices[:1])
orig=next(x for x in inner_scores if x['name']=='original')
if orig not in selected:selected.append(orig)
seen=set();selected=[x for x in selected if not (x['name'] in seen or seen.add(x['name']))]
print('SELECTED for official validation 2025',[x['name'] for x in selected],flush=True)
results=[]
for i,c in enumerate(selected):
 st=time.time()
 try:
  p,model=fit_predict(c['family'],c['params'],train,valid)
  metr=performance(p,valid)
  row={'family':c['family'],'name':c['name'],'params':c['params'],'inner':c['inner'],'val':metr,'seconds':round(time.time()-st,1)}
  results.append(row)
  np.save(OUT/f'pred_{c["name"]}.npy',p)
  print('VAL',f'{i+1}/{len(selected)}',c['family'],c['name'],'r600',round(metr['k600']['recall'],5),'tp',metr['k600']['tp'],'precision600',round(metr['k600']['precision'],5),'auc',round(metr['auc'],5),'seconds',row['seconds'],flush=True)
 except Exception as exc:
  fail.append({'config':c,'error':str(exc)})
  print('FAILED VALID',c['name'],repr(exc),flush=True)
 (OUT/'modelos_arboreos_progreso.json').write_text(json.dumps({'inner':inner_scores,'validacion':results,'failed':fail},indent=2,ensure_ascii=False))

allres={'dataset':str(DATA),'split':'train <2024-03 / embargo Apr-Jun 2024 / inner eval Jul-Dec2024; fit train hasta Dec 2024; validacion Apr-Sep 2025; test/embargo intactos', 'inner':inner_scores,'validacion':results,'failed':fail}
(OUT/'modelos_arboreos_resultados.json').write_text(json.dumps(allres,indent=2,ensure_ascii=False))
print('FINAL RESULTS',[(x['name'],x['val']['k600']['tp']) for x in results],flush=True)

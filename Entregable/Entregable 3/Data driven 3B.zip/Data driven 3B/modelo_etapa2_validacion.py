#!/usr/bin/env python3
"""Casa Oga Etapa 2: modelos comparables y validacion temporal sin utilizar test.
Ejecutar: python modelo_etapa2_comparacion.py [ruta dataset_entrenamiento_v3.csv]
Salida: comparacion_modelos_etapa2.json en carpeta del script.
"""
import sys,json
from pathlib import Path
import numpy as np,pandas as pd,sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, precision_score,recall_score,f1_score,roc_auc_score,average_precision_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,StandardScaler
DATA=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('dataset_entrenamiento_v3.csv')
TARGET='target_cob12_t3'
EXCLUDED={'fecha_mes','id_tienda','id_producto','costo_imputado',TARGET,'split'}
df_all=pd.read_csv(DATA)
df=df_all.loc[df_all.split.isin(['train','validacion'])].copy()
feat=[c for c in df.columns if c not in EXCLUDED]
cat=[c for c in feat if df[c].dtype==object]
num=[c for c in feat if c not in cat]
df[num]=df[num].replace([np.inf],1e3)
train=df[df.split=='train'].copy()
val=df[df.split=='validacion'].copy()
ytr=train[TARGET].astype(int);yval=val[TARGET].astype(int)

preprocessor=ColumnTransformer([('nums',Pipeline([('impute',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler())]),num),('cats',Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore'))]),cat)])
logit=Pipeline([('prep',preprocessor),('clf',LogisticRegression(max_iter=700,class_weight='balanced',random_state=0))])

Xtr=train[feat].copy();Xval=val[feat].copy()
for c in cat:
 full_cats=train[c].astype('category').cat.categories
 Xtr[c]=Xtr[c].astype('category').cat.set_categories(full_cats)
 Xval[c]=Xval[c].astype('category').cat.set_categories(full_cats)
hgb=HistGradientBoostingClassifier(max_iter=300,learning_rate=0.05,class_weight='balanced',categorical_features='from_dtype',random_state=0)
res={'dataset':str(DATA.name),'train':len(train),'validacion':len(val),'positivos_train':int(ytr.sum()),'positivos_validacion':int(yval.sum()),'meses_validacion':int(val.fecha_mes.nunique()),'modelos':{},'baseline':{}}

def metrics(y,p):
 pred=(p>0.5).astype(int)
 tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
 return {'vp':int(tp),'fp':int(fp),'fn':int(fn),'vn':int(tn),'recall':float(recall_score(y,pred)),'precision':float(precision_score(y,pred,zero_division=0)),'f1':float(f1_score(y,pred,zero_division=0)),'auc_roc':float(roc_auc_score(y,p)),'pr_auc':float(average_precision_score(y,p)),'alerts':int(pred.sum())}

def topk(y,score,k):
 tmp=val[['fecha_mes',TARGET,'cobertura']].copy()
 tmp['score']=score
 ids=tmp.sort_values('score',ascending=False).groupby('fecha_mes',sort=False).head(k).index
 selected=tmp.index.isin(ids)
 tp=int(tmp.loc[selected,TARGET].sum());fp=int(selected.sum())-tp
 pos=int(y.sum());neg=len(y)-pos
 return {'vp':tp,'fp':fp,'fn':pos-tp,'vn':neg-fp,'recall':tp/pos,'precision':tp/selected.sum(),'f1':2*tp/(2*tp+fp+pos-tp)}

for name,model,xtrain,xval in [('Regresion logistica',logit,train[feat],val[feat]),('HistGradientBoosting',hgb,Xtr,Xval)]:
 print('Entrenando',name,flush=True)
 model.fit(xtrain,ytr)
 print('Prediciendo',name,flush=True)
 ptrain=model.predict_proba(xtrain)[:,1]
 pval=model.predict_proba(xval)[:,1]
 res['modelos'][name]={'train':metrics(ytr,ptrain),'validacion':metrics(yval,pval),'topk420':topk(yval,pval,420),'topk600':topk(yval,pval,600)}
 print(json.dumps(res['modelos'][name],ensure_ascii=False,indent=2),flush=True)

for k in (420,600):
 res['baseline'][f'cobertura_top{k}']=topk(yval,val.cobertura,k)
pbase=(val['cobertura']>12).astype(int)
res['baseline']['cobertura_umbral12']=metrics(yval,pbase)
res['versiones']={'python':sys.version.split()[0],'pandas':pd.__version__,'numpy':np.__version__,'sklearn':sklearn.__version__}
Path(__file__).with_name('comparacion_modelos_etapa2.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print('GUARDADO',Path(__file__).with_name('comparacion_modelos_etapa2.json'),flush=True)
